import React from 'react'
import ImageItem from '../components/ImageItem'

const PhotoGallery = () => {
  return (
    <ImageItem/>
  )
}

export default PhotoGallery
